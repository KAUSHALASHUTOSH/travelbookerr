from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from .models import TravelOption, Booking
from .forms import UserRegisterForm, BookingForm

def home(request):
    travels = TravelOption.objects.all()
    if request.GET.get('type'):
        travels = travels.filter(type=request.GET['type'])
    if request.GET.get('source'):
        travels = travels.filter(source__icontains=request.GET['source'])
    if request.GET.get('destination'):
        travels = travels.filter(destination__icontains=request.GET['destination'])
    return render(request, 'travel_list.html', {'travels': travels})

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserRegisterForm()
    return render(request, 'register.html', {'form': form})

@login_required
def book_travel(request, travel_id):
    travel = get_object_or_404(TravelOption, pk=travel_id)
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            seats = form.cleaned_data['number_of_seats']
            if seats <= travel.available_seats:
                booking = form.save(commit=False)
                booking.user = request.user
                booking.travel_option = travel
                booking.total_price = seats * travel.price
                booking.status = 'Confirmed'
                booking.save()
                travel.available_seats -= seats
                travel.save()
                return redirect('my_bookings')
    else:
        form = BookingForm()
    return render(request, 'booking_form.html', {'form': form, 'travel': travel})

@login_required
def my_bookings(request):
    bookings = Booking.objects.filter(user=request.user)
    return render(request, 'bookings_list.html', {'bookings': bookings})

@login_required
def cancel_booking(request, booking_id):
    booking = get_object_or_404(Booking, pk=booking_id, user=request.user)
    booking.status = 'Cancelled'
    booking.save()
    booking.travel_option.available_seats += booking.number_of_seats
    booking.travel_option.save()
    return redirect('my_bookings')
