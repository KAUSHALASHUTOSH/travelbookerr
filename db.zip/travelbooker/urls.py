from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from bookings import views as booking_views   # <-- FIXED (plural)

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", booking_views.home, name="home"),

    # Auth
    path("register/", booking_views.register, name="register"),
    path("login/", auth_views.LoginView.as_view(template_name="login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(next_page="home"), name="logout"),

    # Bookings
    path("book/<int:travel_id>/", booking_views.book_travel, name="book_travel"),
    path("my-bookings/", booking_views.my_bookings, name="my_bookings"),
    path("cancel/<int:booking_id>/", booking_views.cancel_booking, name="cancel_booking"),

# Home page
    # path("", TemplateView.as_view(template_name="home.html"), name="home"),

    # Auth routes
    path("login/", auth_views.LoginView.as_view(template_name="login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(next_page="home"), name="logout"),
]